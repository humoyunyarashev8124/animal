import React, { useState } from 'react'
import { getData } from './constants/db'
import Card from './components/card/card'
import Shop from './components/shop/shop'

const animal = getData()

const App = () => {
  const [cartItems, setCartItems] = useState([])

  const onAddItem = item => {
    const existId = cartItems.find(c => c.id == item.id)

    if(existId) {
      const newData = cartItems.map(c => c.id == item.id ? {...existId, quantity: quantity + 1} : c)
      setCartItems(newData)
    }

  }
  const onRemoveItem = item => {
    const existId = cartItems.find(c => c.id == item.id)

    if(existId.quantity == 1) {
      const newData = cartItems.map(c => c.id == item.id ? {...existId, quantity: quantity - 1} : c)
      setCartItems(newData)
    }
  }

  return (
    <div className='container'>
      <Shop />
      {animal.map(animal => (
        <>
          <Card animal={animal} onAddItem={onAddItem} onRemoveItem={onRemoveItem} />
        </>
      ))}
    </div>
  )
}

export default App