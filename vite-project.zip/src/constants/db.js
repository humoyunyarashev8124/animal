export function getData() {
    return (
        [
            {
                title: "Mushuk",
                price: 15000,
                color: "Black",
                Image: 'https://us.feliway.com/cdn/shop/articles/10_fascinating_facts_about_black_cats-3.jpg?v=1667409596',
                id: 1
            },
            {
                title: "Kuchuk",
                price: 15000,
                color: "Black",
                Image: 'https://i2-prod.mylondon.news/incoming/article20940961.ece/ALTERNATES/s615/0_17ffb6ef-dac1-49ca-92ff-a9cf227ce9eb.jpg',
                id: 2
            },
        ]
    )
}