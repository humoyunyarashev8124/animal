import React from 'react'
import './card.css'
import Button from '../button/button'

const Card = props => {
    const {animal, onAddItem, onRemoveItem} = props
  return (
    <div className='card'>
        <span className='card__badge'>0</span>

        <div className="image-container">
            <img src={animal.Image} alt={animal.title} width={'100%'} height={'200px'} />
        </div>

        <div className="card__content">
            <h2 className="card-title">
                {animal.title}
            </h2>
            <p className='card__price'>
                {animal.price}
            </p>
        </div>

        <div className='hr'></div>

        <div className="card-group">
            <Button title={'+'} onClick={onAddItem} type={'add'} />
            <Button title={'-'} onClick={onRemoveItem} type={'remove'} />
        </div>
    </div>
  )
}

export default Card