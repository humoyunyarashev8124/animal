import React from 'react'
import Button from '../button/button'

const Shop = () => {
  return (
    <div>
        <p>Umumiy narx: $100</p>
        <Button title={'checkout'} type={'checkout'} />
    </div>
  )
}

export default Shop